# Validate a puzzle idea

Intake options: ask for a sketch or one-line concept, what the player does and how that action changes the board, the proposed win/loss rules or what evidence already exists. If useful, ask whether the decision is about pitching, prototyping or choosing between concepts.

After intake, read [Puzzle design gates](puzzle.md). Check every applicable idea gate against the brief and evidence. On a sample board, test whether the current rules support two materially different winning paths, a late failure with measurable progress and a 900-coin continue that preserves progress. If the rules prevent these outcomes, show the counterexample. Mark missing rules or evidence as unverified. Label any changed board or rule as a proposed fix. Compare the decision loop with the closest games. Check the 3–5-second gameplay hook and how restricted tutorial steps teach it. Use [Mobile art and game feel](art.md) for portrait layout and panels and [Levels, fairness and economy](levels.md) for progression and revive details.

Deliver the verdict, evidence per gate, the highest-impact changes and the smallest falsifiable test of the prototype's core. Include a corrected **Inspiration** entry if enough source evidence exists. Keep this a concept assessment. Route a request to inspect a playable to `/voodoo-validate`.
