# Validate a puzzle idea

Intake options: ask for a sketch or one-line concept, what the player does and how that action changes the board, the proposed win/loss rules or what evidence already exists. If useful, ask whether the decision is about pitching, prototyping or choosing between concepts.

After intake, read [Puzzle design gates](puzzle.md). Check every idea gate against the brief, available evidence and applicable stage. On a sample board, test whether the current rules support two materially different winning paths, a late failure and a continue that preserves progress. If the rules prevent these outcomes, show the counterexample. Mark missing rules or evidence as unverified. Label any changed board or rule as a proposed fix. Check the closest games and compare the actual decision loop. Audit the first 3–5 seconds of a clip if provided, otherwise storyboard the test. Use [Mobile art and game feel](art.md) for any supplied visuals. Use [Levels, fairness and economy](levels.md) for a detailed progression or revive check.

Deliver the verdict, evidence per gate, the highest-impact changes and the smallest falsifiable V0 test. Include a corrected **Inspiration** entry if enough source evidence exists. A promised feature or an unseen playtest stays unverified. Keep this a concept assessment. Route a request to inspect a playable to `/voodoo-validate`.
