# Create a game from an idea

Intake options: ask which idea or pitch to take forward, which scope to deliver (full game plan, plan plus playable V0, or a scoped V1 build), and the target engine/device or production constraints. If the target is a plan, treat technology choices as plan decisions. Confirm when the brief already contains all inputs.

After intake, read [Puzzle design gates](puzzle.md), [Levels, fairness and economy](levels.md), [Mobile art and game feel](art.md), and [Prototype, creative and test plan](testing.md). Screen for blockers, identify evidence gaps and propose scoped fixes for the chosen concept. If a hard gate needs a fundamentally different concept, surface the decision before rewriting the premise.

Deliver a full game plan with these sections.

1. Concept, audience, one-line pitch and **Inspiration** with the new decision.
2. Controls, core loop, board/state, action rules, legal and illegal feedback, win/loss and revive. Include a reproducible example with two different solutions and one recoverable error.
3. L1–20 specifications with level personalities, fail-safe tutorials, hard/easy pairs and the loop back from L20 to about L6. Include seeded variation, a path to V2/L50 and 1,000-level QA, progression metrics and revive economy.
4. Portrait gameplay and panel flow, including Win, Game Over and a Main Menu planned for a later version. Specify each panel's content, actions and destination. Include palette roles, board hierarchy, asset references, motion/audio/haptics and readability checks.
5. First 3–5-second hook, sample win/lose states for the pitch, five CPI angles for V1, and where each ad moment appears in L1–3. Include instrumentation and playtest criteria.
6. V0 → V1 → V2 deliverables, dependencies, scope decisions and acceptance checks. Order work by risk and prioritize touch, feedback and the core loop.

If the agreed scope includes a build, follow the project's entry points and implement that playable scope. Use the existing stack, or a small self-contained HTML5 V0 when agreed and no stack is prescribed. Verify portrait behavior and the input → result panel → next level or retry/revive flow. For a complete V1, run the V1 checklist in the test reference. Hand over the runnable path, controls and verification gaps. A written plan is the deliverable when plan-only is selected.
