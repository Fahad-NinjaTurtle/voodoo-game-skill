# Create a game from an idea

Intake options include the chosen idea, target engine/device and required assets. A request to create the game includes a plan and one finished playable prototype. Honor an explicitly requested plan-only scope. Confirm any material decision that the brief leaves open.

After intake, read [Puzzle design gates](puzzle.md), [Levels, fairness and economy](levels.md), [Mobile art and game feel](art.md), and [Prototype acceptance and loss logging](testing.md). Screen for blockers, identify evidence gaps and propose scoped fixes for the chosen concept. If a hard gate needs a fundamentally different concept, surface the decision before rewriting the premise.

Deliver a full game plan with these sections.

1. Concept, audience, one-line pitch and **Inspiration** with the new decision.
2. Controls, core loop, board/state, action rules, legal and illegal feedback, win/loss and revive. Include a reproducible example with two different solutions and one recoverable error.
3. L1–20 specifications with level personalities, restricted tutorial steps and animated hand cues, hard/easy pairs and the loop back from L20 to about L6. Include seeded variation and the revive economy.
4. Portrait Main Menu, gameplay, Win and Game Over flow. Specify each panel's content, actions and destination. Include palette, asset references and particles, screen shake, sound and phone vibration per action.
5. Objective-progress logging at each loss, the 900-coin revive behavior, and acceptance checks for the complete player flow. Exclude all ad code, stubs, SDKs, placements and ad-gated actions.

For a build, use the existing stack and its normal entry points. When an agreed browser build has no stack, use HTML5 and keep the playable viewport in portrait. Run the acceptance checklist, hand over a runnable path and identify remaining device checks. For a plan-only request, deliver the plan with the same acceptance criteria.
