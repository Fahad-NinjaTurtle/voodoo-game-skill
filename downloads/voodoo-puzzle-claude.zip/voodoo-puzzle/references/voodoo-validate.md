# Validate a game or prototype

Intake options include where to find the playable prototype, source, clip or loss logs, the target device, and which acceptance decision matters. Ask for a test state or reproduction steps when relevant.

After intake, read [Puzzle design gates](puzzle.md). Use [Levels, fairness and economy](levels.md) for progression, [Mobile art and game feel](art.md) for portrait panels and feedback, and [Prototype acceptance and loss logging](testing.md) for a full audit or loss evidence. Exercise the normal player path where possible. For a full audit, run the acceptance checklist and check decision depth and seeded replays. Keep focused audits within the requested levels and criteria. Use source and runtime evidence for input gating, economy, ad absence and log accuracy. A clip supports visible behavior. Confirm phone vibration on a supported phone or mark it unverified.

Deliver one verdict with prioritized findings. For each include severity, gate, specific scene/level/seed/timecode/file/cohort, observed result, expected result and smallest useful fix or test. Identify missing evidence and provide a short reproducible retest. This workflow is read-only.
