# Generate puzzle ideas

Intake options: ask whether to start from scratch or use an optional example, toy, game or mechanic. Ask what player appeal, prototype scope or mechanic constraints matter most. One example is enough for a seed. A visual example can inform execution after finding a real mechanical origin.

If the brief also requests a playable, clarify in the same batch whether to build it in this run, who picks the candidate, and the engine or device if it affects the work. A prototype constraint by itself can guide the shortlist.

After intake, read [Puzzle design gates](puzzle.md). Use real sources outside the current mobile top 100 and, where browsing is available, verify what they do and look for near copies. Extract the rewarding interaction and simplify it for touch. Explore distinct decisions instead of changing the skin. Default to three candidates and one recommendation.

For each candidate give a one-line pitch, filled **Inspiration**, gesture → consequence → next choice, a visible payoff, goal and resource pressure, a late-loss moment and coin revive, level variation and the biggest risk. Include a portrait board sketch or state sequence for the strongest idea. Show two choices, a guided tutorial action, the lose condition and a measurable objective-progress metric. Describe the particles, shake, sound and vibration that accompany the main action. Use [Mobile art and game feel](art.md) when asked for art direction, footage or a mockup.

When this run includes a playable prototype and the user selected the idea or delegated selection, load [Levels, fairness and economy](levels.md), [Prototype acceptance and loss logging](testing.md), and the art reference after shortlisting. Build the finished prototype and verify the same acceptance criteria as `/voodoo-create`. Use `/voodoo-create` for a separate request to plan or build the chosen game.
