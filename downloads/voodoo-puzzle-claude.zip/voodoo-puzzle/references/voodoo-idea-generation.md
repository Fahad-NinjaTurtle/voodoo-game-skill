# Generate puzzle ideas

Intake options: ask whether to start from scratch or use an optional example, toy, game or mechanic. Ask what player appeal, prototype scope or mechanic constraints matter most. One example is enough for a seed. A visual example can inform execution after finding a real mechanical origin.

If the brief also requests a playable, clarify in the same batch whether to build it in this run and who picks the candidate. A prototype constraint by itself can guide the shortlist.

After intake, read [Puzzle design gates](puzzle.md). Use real sources outside the current mobile top 100 and, where browsing is available, verify what they do and look for near copies. Extract the rewarding interaction and simplify it for touch. Explore distinct decisions instead of changing the skin. Default to three candidates and one recommendation.

For each candidate give a one-line pitch, filled **Inspiration**, gesture → consequence → next choice, goal and resource pressure, near-loss and revive, first 3–5 seconds of an ad, visual metaphor, core-only level variation and biggest gate risk. Include a simple board sketch or state sequence for the strongest idea showing two choices and the lose condition. Prefer the candidate with a credible small V0 and say what could disprove it fastest. Use [Mobile art and game feel](art.md) when asked for an art direction, shot or mockup.

When this run includes an agreed playable and the user selected the idea or delegated selection, load [Prototype, creative and test plan](testing.md) and the art reference after shortlisting. Build the agreed V0 loop, check win/fail/retry and deliver its runnable location. Use `/voodoo-create` for a separate full game plan or production build.
