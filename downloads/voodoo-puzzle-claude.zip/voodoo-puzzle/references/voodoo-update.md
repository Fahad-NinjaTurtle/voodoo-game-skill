# Update an existing puzzle game

Intake options include the current project or playable, the changes to make, rules or data to preserve, and whether to deliver a prioritized plan or implement it.

After intake, read [Puzzle design gates](puzzle.md). Use [Levels, fairness and economy](levels.md) for progression, tutorial or revive changes, [Mobile art and game feel](art.md) for portrait panels or feedback, and [Prototype acceptance and loss logging](testing.md) for a full update or telemetry. Reproduce the issues with available evidence. Prioritize gaps by player impact and propose the smallest fix. Carry forward working project patterns and save compatibility. Show before/after behavior, acceptance checks and any required migration. If a fix changes the core idea or conflicts with a user constraint, ask about that tradeoff before applying it.

For implementation, make targeted edits. A full update brings the existing game to one finished prototype using the acceptance checklist, including the Main Menu and result panels, restricted tutorials, action feedback, no in-game ads, coin revive and loss logging. For scoped edits, verify affected flows, replays and existing saves or level data. Deliver the updated playable or patch references, verification gaps and retest steps. A plan-only request produces a prioritized patch plan with acceptance checks.
